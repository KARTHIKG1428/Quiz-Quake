# QuizQuake: BrainStorm Arena

**College mini-project | Adaptive quiz and learning assessment platform**

QuizQuake is a responsive React + TypeScript quiz application with an Express API, topic-tagged computer science MCQs, adaptive difficulty, timed assessment, topic diagnostics, answer explanations, local attempt history, remedial practice, and print/PDF report export.

## Project contents
- `client/` – React + TypeScript frontend
- `server/` – Express API
- `data/questions.json` – sample question bank
- `docs/Project_Report.md` – college project report
- `docs/Presentation_Guide.md` – suggested presentation flow

## Requirements
- Node.js 18 or newer
- npm

## Run locally
Open a terminal in this directory and run:

```bash
npm run install:all
npm run dev
```

Open **http://localhost:5173**. The API runs at **http://localhost:4000**.

To create a production frontend build:

```bash
npm run build
```

To run the API:

```bash
npm start
```

## Main features
- 60 sample MCQs across Data Structures, Algorithms, Operating Systems, and Computer Networks
- Easy, Medium, and Hard difficulty levels
- Adaptive difficulty based on consecutive answers
- 10-question / 10-minute assessment
- Topic-wise diagnostic report and radar chart
- Answer review with explanations
- 5-question remedial practice mode
- Recent attempt history stored in browser localStorage
- Print report / Save as PDF

## Adaptive rules
- Start at Easy.
- Two consecutive correct answers move up one tier (Easy → Medium → Hard).
- One incorrect answer moves down one tier (Hard → Medium; otherwise Easy).
- The quiz aims to rotate across the four topic domains before repeating a topic.

## Notes
- Attempt history is stored in the browser's localStorage on that device/browser.
- The report's **Export / print report** button opens the browser print dialog; choose **Save as PDF**.
- Questions are sample educational content for demonstration and should be reviewed by faculty before formal examination use.
- The backend currently reads the question bank from a JSON file; it is not a database-backed multi-user system.

## Presentation
See `docs/Project_Report.md` for the report and `docs/Presentation_Guide.md` for a slide-by-slide speaking guide. The ZIP also includes a PowerPoint presentation in the top-level `presentation/` folder.
