# Presentation Guide – QuizQuake

Suggested 7–9 minute presentation:

1. **Title:** QuizQuake – BrainStorm Arena. Introduce the project and team.
2. **Problem:** Fixed quizzes do not always match a learner's current level and provide limited topic-specific guidance.
3. **Objectives:** Timed quiz, adaptive difficulty, topic analytics, explanations, and remedial practice.
4. **Technology:** React, TypeScript, Vite, Express, JSON question bank, Chart.js, and localStorage.
5. **Architecture:** Browser UI → Express API → JSON question bank; client calculates results and stores local attempt history.
6. **Workflow:** Start quiz → answer questions → difficulty adapts → view report → review answers → practise weaker topics.
7. **Adaptive rules:** Start Easy; two correct answers raise difficulty; incorrect answers reset the streak and may lower difficulty.
8. **Demo:** Run the app, complete a few questions, and show the result screen and review page.
9. **Conclusion and future scope:** Summarise benefits; mention login, database, faculty dashboard, and more subjects as future work.

**Before submission:** Add your name, roll number, department, college, guide name, and academic year to the title slide and report cover page.
