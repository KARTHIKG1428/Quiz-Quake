# QUIZQUAKE – BRAINSTORM ARENA
## College Mini-Project Report

### 1. Abstract
QuizQuake is a responsive web-based quiz and learning assessment application for computer science topics. It presents multiple-choice questions, adjusts question difficulty based on a learner's recent answers, and provides a performance report with topic-wise analysis. Learners can review explanations, practise weaker topics, and view recent attempts stored in their browser.

### 2. Problem Statement
A fixed-difficulty quiz may not reflect a learner's current understanding. Learners also need clear feedback about the topics they should practise next. QuizQuake demonstrates an interactive assessment workflow that combines timed quizzes, adaptive difficulty, and topic-level feedback.

### 3. Objectives
- Provide a simple and responsive quiz interface.
- Organise questions by topic and difficulty.
- Adjust difficulty in response to answer streaks.
- Show an overall score and topic-wise accuracy.
- Explain answers and support targeted practice.
- Keep a small history of attempts in the local browser.

### 4. Scope
The demonstration covers Data Structures, Algorithms, Operating Systems, and Computer Networks. It includes a 10-question timed assessment and a shorter remedial practice mode. The question bank is sample educational content and should be reviewed by faculty before formal assessment use.

### 5. Technology Stack
- Frontend: React, TypeScript, Vite, HTML, and CSS
- Charts: Chart.js with react-chartjs-2
- Backend: Node.js and Express
- Data: JSON question bank
- Browser storage: localStorage for attempt history

### 6. System Modules
1. **Home screen:** introduces the platform and shows recent attempts.
2. **Question bank:** supplies topic-tagged questions and answer explanations.
3. **Adaptive quiz:** presents questions, tracks time, and changes difficulty.
4. **Diagnostic report:** calculates overall and topic-wise accuracy.
5. **Solution review:** displays the selected answer, correct answer, and explanation.
6. **Remedial practice:** creates a short practice round from topics below the mastery threshold.
7. **History and export:** stores recent attempts locally and supports printing the report to PDF.

### 7. Adaptive Logic
- The quiz begins at Easy difficulty.
- Two consecutive correct answers increase the difficulty by one level.
- An incorrect answer resets the streak and reduces the level where possible.
- Questions are selected to rotate across topic areas.
- The main assessment contains 10 questions with a 10-minute limit.
- The remedial round contains 5 questions with a 5-minute limit.

### 8. System Architecture
The React client requests the question bank from the Express API. During an attempt, the client tracks answers and timing, calculates the diagnostic report, and saves attempt history in localStorage. The API exposes health, question-bank, and diagnostic endpoints.

### 9. How to Run
Requirements: Node.js 18 or newer and npm.

From the `quizquake-project` directory:

```bash
npm run install:all
npm run dev
```

Open `http://localhost:5173` in a browser. The API runs at `http://localhost:4000`.

For a production frontend build:

```bash
npm run build
```

### 10. Testing Checklist
- Start the app and confirm the home screen loads.
- Start a quiz and confirm the question and timer appear.
- Select an option and submit an answer.
- Confirm the progress indicator advances.
- Complete the quiz and check the overall score.
- Open solution review and verify explanations are displayed.
- Try the remedial practice option when a topic is below 60%.
- Refresh the browser and confirm recent attempt history remains available.
- Use the print/export action and choose Save as PDF.

### 11. Advantages
- Easy-to-use interface.
- Immediate feedback and explanations.
- Adaptive difficulty makes the demonstration more engaging.
- Topic-wise analysis helps identify practice areas.
- Uses a lightweight JSON question bank.

### 12. Limitations
- Attempt history is stored only in the same browser/device.
- The sample project does not include user accounts or a central database.
- The question bank is demonstration content, not a validated examination bank.
- The adaptive rules are intentionally simple and are not a formal measurement of ability.

### 13. Future Enhancements
- Add student and faculty login.
- Store results in a database.
- Allow faculty to create and import question sets.
- Add class-level analytics and leaderboards.
- Support additional subjects and languages.
- Add accessibility and usability testing.

### 14. Conclusion
QuizQuake demonstrates how a web application can combine a timed quiz, simple adaptive difficulty, answer explanations, and topic-wise performance feedback. It provides a foundation that can be extended with authentication, database storage, and faculty-managed assessments.

### 15. Demonstration Note
Before presenting, run the application locally and test the quiz flow. Replace the student/institution details on the presentation title slide with the correct details.
